// // step1

// Creating the folder and set up of it using npm init -y

// // step2

// Create Server Code with Room ;

// const express = require("express")
// const http  =require("http")
// const WebSocket = require("ws")

// const app  =express()
// const server = http.createServer(app)
// const wss = new WebSocket.Server({server})

// // map to tracks user and rooms

// const users = new Map()
// const rooms  = new Map()

// app.use(express.static('public'))

// wss.on('connections',(ws) => {
//     ws.on("messages",(data) => {
//         let messages
//         try {
//             msg = JSON.parse(data)
//         }
//         catch(err){
//             return err
//         }

//         if(messages.type === 'register'){
//             users.set(ws,{userId:msg.userId,roomId:null})
//             ws.send(JSON.stringify({type:"info",message:"Regisered as" + msg.userId}))
//         }
//         if(msg.type === "join"){
//             const used = users.get(ws)
//             if(!user) return

//             const room  = msg.roomId
//             user.roomId = roomId

//             if(!room.has(roomId)){
//                 rooms.set(roomId,new Set())
//             }
//             rooms.get(roomId).add(ws)
//             ws.send(JSON.stringify({type:'info',messgae : 'Joined room ' + roomId}))
//         }
//     })

//     ws.on('close',() => {
//         const user = users.get(ws)
//         if(user && user.roomId){
//             const user = room.get(user.roomId)
//             if(room){
//                 room.delete(ws)

//             }
//         }
//         users.delete(ws)
//     })
// })

// server.listen(3000 ,() => {
//     console.log("Web Sockets running on http : //localhost:3000")
// })
