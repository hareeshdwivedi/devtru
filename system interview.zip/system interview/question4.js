// Example 1:
let num = [2, 7, 11, 15];
let target = 9;

function targetElementIndices(num, target) {
  const map = new Map();

  for (let i = 0; i < num.length; i++) {
    const complement = target - num[i];

    if (map.has(complement)) {
      return [map.get(complement), i];
    }
    map.set(num[i], i);
  }
  return [];
}

console.log(targetElementIndices(num, target));
